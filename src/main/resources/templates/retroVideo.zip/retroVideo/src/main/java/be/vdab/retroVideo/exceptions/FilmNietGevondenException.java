package be.vdab.retroVideo.exceptions;

public class FilmNietGevondenException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}
